let = [
    {
        "Profile_img":"C:\Users\Public\Pictures\Sample Pictures\Chrysanthemum.jpg",
        "Name":"jayasoorya",
        "Posted":"Just Now",
        "Message":"Hello guys very good morning to all....",
        "img":"C:\Users\Public\Pictures\Sample Pictures\Chrysanthemum.jpg",
        "Likes_count":"5 Likes",
        "Comment":"2 Comments"
    },
    {
        "Profile_img":"C:\Users\Public\Pictures\Sample Pictures\Desert.jpg",
        "Name":"Aurmugam",
        "Posted":"10 mins ago",
        "Message":"It's tea time am i right? ",
        "img":"C:\Users\Public\Pictures\Sample Pictures\Desert.jpg",
        "Likes_count":"25 Likes",
        "Comment":"8 Comments"
    },
    {
        "Profile_img":"C:\Users\Public\Pictures\Sample Pictures\Hydrangeas.jpg",
        "Name":"Vadivelu",
        "Posted":"2 mins ago",
        "Message":"Vanakkam",
        "img":"C:\Users\Public\Pictures\Sample Pictures\Hydrangeas.jpg",
        "Likes_count":"15 Likes",
        "Comment":"25 Comments"
    },
    {
        "Profile_img":"C:\Users\Public\Pictures\Sample Pictures\Jellyfish.jpg",
        "Name":"Kumar",
        "Posted":"1 hr ago",
        "Message":"Book me",
        "img":"C:\Users\Public\Pictures\Sample Pictures\Jellyfish.jpg",
        "Likes_count":"8 Likes",
        "Comment":"22 Comments"
    },
] 